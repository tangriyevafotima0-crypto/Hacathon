# SKYFORGE Bk B01/B02 — tekshirilgan paket

Bu ZIP loyiha manba kodini, Z yadrosini, GitHubdan olingan D ma’lumotlarini, brauzer dalillarini va tayyor `dist/` buildni saqlaydi. Argon topshiriqlari bajarilmagan va uning fayllari o‘zgartirilmagan.

## Ishlatish

Node.js 22.12 yoki yangiroq versiya:

    npm ci
    npm test
    npm run build
    npm run dev

Birinchi ekranda `Seed preview` → bayroqlarni tasdiqlash → `Tasdiqlash va saqlash`. BASS-II ni ochib T20/T21 ni tanlang. `T25 demo preview` bilan uchinchi sinovni import qiling. `dist/index.html`ni file:// orqali ochmang, `npm run preview` ishlating.

## GitHubga o‘zingiz push qilish

Amaldagi Hacathon reposini yangilab oling. ZIPdagi quyidagi o‘zgargan/yangi yo‘llarni mos joyga ko‘chiring:

- src/main.jsx
- src/atlas/ui/
- src/atlas/data/
- tests/atlas/data.test.js
- tests/atlas/notebook.test.js
- docs/bk/
- README.md
- PUSH-UZ.md

Keyin `git diff`ni ko‘rib chiqing, `npm ci`, `npm test`, `npm run build`ni bajaring. O‘zingiz ishlatadigan branchga commit va push qiling. `node_modules`, `dist` va `.git`ni GitHubga qo‘shish shart emas. Z core, package-lock va Argon fayllari almashtirilmagan. ZIP ichidagi oldingi `MANIFEST.sha256` tarixiy Z paketiga tegishli; yangi ZIPning nazorat yig‘indilari `PACKAGE-SHA256.txt`da.

## Haqiqiy holat

46 test PASS; production build PASS; Chromium desktop/390px, T25 import/reload/repeated import, manba paneli, CSV/JSON download, notebook reopen, import cancel va corrupt-store tekshiruvlari PASS. Batafsil: docs/bk/HANDOFF.md va docs/bk/validation/.

Z02 erkin savol parseri/ranking, live API va hosted offline reload hali ulanmagan. Ilova hech qanday Oy/Mars yonish xavfi foizini taxmin qilmaydi. Mustaqil Analyzer/PM tasdig‘i olinmagan. Barcha ehtimoliy xatolar yo‘qligi haqida kafolat berilmaydi.
